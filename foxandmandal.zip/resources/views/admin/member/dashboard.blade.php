@extends('layouts.app')

@section('content')
<div class="container mt-2">
        <div class="col-md-12">
            <div class="row">
                <div class="container mt-2">
                    <div class="col-md-12">
                        <div class="row">

                            <div class="col-md-4 mb-4">
                                <div class="card shadow-sm rounded p-3 d-flex flex-row align-items-center justify-content-between">
                                    <div>
                                        <div class="text-muted">Total Letters</div>
                                        <div class="h5 mb-0 font-weight-bold text-dark">{{ $total }}</div>
                                    </div>
                                    <div class="bg-dark text-white rounded-circle p-2">
                                        <i class="fas fa-file-alt"></i>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4 mb-4">
                                <div class="card shadow-sm rounded p-3 d-flex flex-row align-items-center justify-content-between">
                                    <div>
                                        <div class="text-muted">Total Received</div>
                                        <div class="h5 mb-0 font-weight-bold text-dark">{{ $delivered }}</div>
                                    </div>
                                    <div class="bg-success text-white rounded-circle p-2">
                                        <i class="fas fa-check-circle"></i>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4 mb-4">
                                <div class="card shadow-sm rounded p-3 d-flex flex-row align-items-center justify-content-between">
                                    <div>
                                        <div class="text-muted">Pending to Receive</div>
                                        <div class="h5 mb-0 font-weight-bold text-dark">{{ $pending }}</div>
                                    </div>
                                    <div class="bg-warning text-white rounded-circle p-2">
                                        <i class="fas fa-file-contract"></i>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>  
                <div class="card mt-3">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Letter List</h5>
                        <a href="{{ route('home', ['status' => 'Delivered']) }}" class="btn btn-outline-dark btn-sm">
                            Show Only Delivered
                        </a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered mb-0">
                            <thead>
                                <tr>
                                    <th>Letter ID</th>
                                    <th>Subject</th>
                                    <th>Status</th>
                                    <th>Created At</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($letters as $letter)
                                    <tr>
                                        <td>{{ $letter->letter_id }}</td>
                                        <td>{{ $letter->subject ?? 'N/A' }}</td>
                                        <td>
                                            <span class="badge {{ $letter->status == 'Delivered' ? 'bg-success' : 'bg-warning text-dark' }}">
                                                {{ $letter->status }}
                                            </span>
                                        </td>
                                        <td>{{ \Carbon\Carbon::parse($letter->created_at)->format('d-m-Y') }}</td>
                                    </tr>
                                @empty
                                    <tr><td colspan="4" class="text-center">No letters found.</td></tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
</div>
@endsection