@extends('layouts.app')
@section('content')


<div class="container mt-2">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5>Letter Management</h5>
                    <div>
                        <button class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#addLetterModal">+ Add Letter</button>
                        <a href="{{route('admin.letter.export')}}" class="btn btn-outline-secondary btn-sm">Export Letters</a>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Received From</th>
                                <th>Handed Over By</th>
                                <th>Send To (Member/Team)</th>
                                <th>Subject/Document Name</th>
                                <th>Document Reference No & Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($letters as $letter)
                                <tr>
                                    <td>{{ $letter->letter_id }}</td>
                                    <td>{{ ucwords($letter->received_from) }}</td>
                                    <td>{{ ucwords($letter->handedOverByUser->name ?? 'N\A') }}</td>
                                    {{-- <td>{{ $letter->send_to }}</td> --}}
                                    <td>
                                        @php
                                            $sendTo = $letter->send_to;
                                            $sendToName = '';

                                            if(Str::startsWith($sendTo, 'member_')) {
                                                $memberId = Str::after($sendTo, 'member_');
                                                $member = \App\Models\User::find($memberId);
                                                $sendToName = $member ? ucwords($member->name) . ' (Member)' : 'Unknown Member';
                                            } elseif(Str::startsWith($sendTo, 'team_')) {
                                                $teamId = Str::after($sendTo, 'team_');
                                                $team = \App\Models\Team::find($teamId);
                                                $sendToName = $team ? ucwords($team->name)  : 'Unknown Team';
                                            }
                                        @endphp

                                        {{ $sendToName }}
                                    </td>
                                    <td>{{ ucwords($letter->subject) }}</td>
                                    <td>{{ $letter->document_reference_no }}{{ $letter->document_date ? ',' . date('d-m-Y',strtotime($letter->document_date)) : '' }}</td>
                                    <td>
                                        <span class="badge bg-{{ $letter->status == 'Delivered' ? 'badge bg-success text-white' : 'badge bg-warning text-dark' }}">
                                            {{ $letter->status }}
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-primary edit-letter-btn"
                                            data-id="{{ $letter->id }}"
                                            data-received_from="{{ $letter->received_from }}"
                                            data-send_to="{{ $letter->send_to }}"
                                            data-document_reference_no="{{ $letter->document_reference_no }}"
                                            data-document_date="{{ $letter->document_date }}"
                                            data-subject="{{ $letter->subject }}"
                                            data-handed_over_by="{{ $letter->handed_over_by }}"
                                            data-document_image="{{ $letter->document_image }}">
                                            <i class="fa fa-pen"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger deleteBtn" data-id="{{ $letter->id }}"><i class="fa fa-trash"></i></button>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                {{-- modal --}}
                <div class="modal fade" id="addLetterModal" tabindex="-1">
                    <div class="modal-dialog modal-lg"> 
                        <form id="letterForm" method="POST" action="{{ route('admin.letter.store') }}" enctype="multipart/form-data">
                            @csrf
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Add New Letter</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>

                                <div class="modal-body">
                                    <div class="row g-3">
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Received From</label>
                                            <input type="text" name="received_from" class="form-control" placeholder="Enter senders name and address">
                                        </div>


                                        <div class="col-md-6">
                                            <label class="form-label">Send To (Member/Team)</label>
                                            <select name="send_to" class="form-select">
                                                <option value="">Select member or team</option>

                                                {{-- <optgroup label="Members">
                                                    @foreach($members as $member)
                                                        <option value="member_{{ $member->id }}">
                                                            {{ $member->name }} ({{ ucfirst($member->role) }})
                                                        </option>
                                                    @endforeach
                                                </optgroup> --}}

                                                <optgroup label="Members">
                                                    @foreach($members as $member)
                                                        @php
                                                            $teamNames = $member->team->pluck('name')->implode(', ');
                                                        @endphp
                                                        <option value="member_{{ $member->id }}">
                                                            {{ $member->name }}
                                                            @if($teamNames)
                                                                ({{ $teamNames }} Member)
                                                            @endif
                                                        </option>
                                                    @endforeach
                                                </optgroup>


                                                <optgroup label="Teams">
                                                    @foreach($teams as $team)
                                                        <option value="team_{{ $team->id }}">
                                                            {{ $team->name }}
                                                        </option>
                                                    @endforeach
                                                </optgroup>
                                            </select>
                                        </div>

                                        <div class="col-md-6">
                                            <label class="form-label">Document Reference No</label>
                                            <input type="text" name="document_reference_no" class="form-control" placeholder="Enter reference number and date">
                                        </div>

                                        <div class="col-md-6">
                                            <label class="form-label">Document Date</label>
                                            <input type="date" name="document_date" class="form-control" placeholder="Enter date">
                                        </div>

                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Subject/Document Name</label>
                                            <input type="text" name="subject" class="form-control" placeholder="Enter subject or document name">
                                        </div>

                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Handed Over By</label>
                                            <select name="handed_over_by" class="form-select">
                                                <option value="">Select Person</option>
                                                @foreach($users as $user)
                                                    <option value="{{ $user->id }}">{{ $user->name }} ({{ ucfirst($user->role) }})</option>
                                                @endforeach
                                            </select>
                                        </div>

                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Upload Image / PDF</label>
                                            <input type="file" name="document_image" class="form-control" accept="image/*,application/pdf">
                                            <small class="text-muted">(Accepts images or PDF files. Optional.)</small>
                                        </div>
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-dark">Add Letter</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="modal fade" id="editLetterModal" tabindex="-1">
                    <div class="modal-dialog modal-lg">
                        <form id="editLetterForm" method="POST" enctype="multipart/form-data">
                            @csrf
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Edit Letter</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="letter_id" id="editLetterId">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label>Received From</label>
                                            <input type="text" name="received_from" id="editReceivedFrom" class="form-control" placeholder="Enter senders name and address">
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Send To (Member/Team)</label>
                                            {{-- <select name="send_to" id="editSendTo" class="form-select">
                                                <option value="" disabled selected>Select member/team</option>
                                                @foreach($members as $member)
                                                    <option value="{{ $member->name }}">{{ $member->name }}</option>
                                                @endforeach
                                            </select> --}}
                                            <select name="send_to" id="editSendTo" class="form-select">
                                                <option value="" disabled selected>Select member/team</option>
                                                <optgroup label="Members">
                                                    @foreach($members as $member)
                                                            @php
                                                                $teamNames = $member->team->pluck('name')->implode(', ');
                                                            @endphp
                                                            <option value="member_{{ $member->id }}">
                                                                {{ $member->name }}
                                                                @if($teamNames)
                                                                    ({{ $teamNames }} Member)
                                                                @endif
                                                            </option>
                                                    @endforeach
                                                </optgroup>
                                                <optgroup label="Teams">
                                                    @foreach($teams as $team)
                                                        <option value="team_{{ $team->id }}">{{ $team->name }}</option>
                                                    @endforeach
                                                </optgroup>
                                            </select>
                                        </div>


                                        <div class="col-md-6">
                                            <label>Document Reference No</label>
                                            <input type="text" name="document_reference_no" id="editReference" class="form-control" placeholder="Enter reference number and date">
                                        </div>
                                        <div class="col-md-6">
                                            <label>Document Date</label>
                                            <input type="date" name="document_date" id="editDocumentDate" class="form-control" placeholder="Enter date">
                                        </div>
                                        <div class="col-md-6">
                                            <label>Subject/Document Name</label>
                                            <input type="text" name="subject" id="editSubject" class="form-control" placeholder="Enter subject or document name">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Handed Over By</label>
                                            <select name="handed_over_by" id="editHandedOverBy" class="form-select">
                                                <option value="" disabled selected>Select person</option>
                                                @foreach($users as $user)
                                                    <option value="{{ $user->id }}">{{ $user->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label>Upload Image / PDF</label>
                                            <input type="file" name="document_image" id="editDocumentImage" class="form-control">
                                            <small class="text-muted">(Accepts images or PDF files. Optional.)</small>
                                            <div id="existingDocumentPreview" class="mt-2"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-dark">Update Letter</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('script')
<script>
    $('#letterForm').on('submit', function (e) {
        e.preventDefault();
        const form = this;
        const formData = new FormData(form);

        $.ajax({
            type: 'POST',
            url: form.action,
            data: formData,
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.status) {
                    toastFire('success', res.message);
                    $('#addLetterModal').modal('hide');
                    form.reset();
                    setTimeout(() => location.reload(), 800);
                } else {
                    toastFire('error', res.message);
                }
            },
            error: function (xhr) {
                let err = xhr.responseJSON?.message || 'Something went wrong.';
                toastFire('error', err);
            }
        });
    });

    $('.edit-letter-btn').on('click', function () {
        const id = $(this).data('id');

        $('#editLetterId').val(id);
        $('#editReceivedFrom').val($(this).data('received_from'));
       // $('#editSendTo').val($(this).data('send_to'));
        $('#editSendTo').val('').trigger('change');
        const sendToValue = $(this).data('send_to');

        if (sendToValue) {
            $('#editSendTo').val(sendToValue).trigger('change');
        } else {
            $('#editSendTo').val('').trigger('change');
        }
        $('#editReference').val($(this).data('document_reference_no'));
        $('#editDocumentDate').val($(this).data('document_date'));
        $('#editSubject').val($(this).data('subject'));
        // $('#editHandedOverBy').val($(this).data('handed_over_by'));
        const handedOverBy = $(this).data('handed_over_by');

        if (handedOverBy) {
            $('#editHandedOverBy').val(handedOverBy).trigger('change');
        } else {
            $('#editHandedOverBy').val('').trigger('change');
        }
        
        const filename = $(this).data('document_image');
        if (filename) {
            const extension = filename.split('.').pop().toLowerCase();
            const fileUrl = `/uploads/letters/${filename}`;

            if (extension === 'pdf') {
                $('#existingDocumentPreview').html(
                    `<p class="text-muted">Existing File: <a href="${fileUrl}" target="_blank">${filename}</a></p>`
                );
            } else {
                $('#existingDocumentPreview').html(
                    `<p class="text-muted">Existing File:</p>
                    <img src="${fileUrl}" alt="Uploaded Image" class="img-fluid rounded" width="100">`
                );
            }
        } else {
            $('#existingDocumentPreview').html('');
        }
        
        const action = "{{ route('admin.letter.update', ['id' => '__id__']) }}".replace('__id__', id);
        $('#editLetterForm').attr('action', action);

        $('#editLetterModal').modal('show');
    });

   $('#editLetterForm').on('submit', function (e) {
        e.preventDefault();

        const form = this;
        const id = $('#editLetterId').val();
        const formData = new FormData(form); 

        $.ajax({
            type: 'POST',
            url: `/letter-management/update/${id}`,
            data: formData,
            processData: false,
            contentType: false,
            success: function (res) {
                if (res.status) {
                    toastFire('success', res.message);
                    $('#editLetterModal').modal('hide');
                    setTimeout(() => location.reload(), 800);
                } else {
                    toastFire('error', res.message);
                }
            },
            error: function (xhr) {
                const err = xhr.responseJSON?.message || 'Something went wrong.';
                toastFire('error', err);
            }
        });
    });



    $('.deleteBtn').on('click', function (e) {
        e.preventDefault();
        const btn = $(this);
        const userId = btn.data('id');

        Swal.fire({
            title: 'Are you sure?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.post("{{ route('admin.letter.delete', ['id' => '__id__']) }}".replace('__id__', userId), {
                    _token: '{{ csrf_token() }}'
                }, function (res) {
                    if (res.status) {
                        toastFire('success', res.message);
                        btn.closest('tr').remove(); 
                    } else {
                        toastFire('error', res.message);
                    }
                });
            }
        });
    });

</script>

@endsection
