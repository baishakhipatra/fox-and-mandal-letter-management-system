<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{User, Team};
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;

class UserManagementController extends Controller
{
    public function index()
    {
        $users = User::with('team')->where('role', '!=', 'Super Admin')->paginate(10);
        $teams = Team::all();
        return view('admin.user-management.index',compact('users','teams'));
    }

    public function store(Request $request){
        $request->validate([
            'name' => 'required|string',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6',
            'role' => 'required',
            'team_id' => 'nullable|exists:teams,id',
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => $request->role,
            'status' => 1,
        ]);


        if ($request->role === 'Member' && $request->filled('team_id')) {
            DB::table('team_members')->insert([
            'team_id' => $request->team_id,
            'user_id' => $user->id,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

        return response()->json(['status' => true, 'message' => 'User Added Successfully']);
    }

    // public function update(Request $request, $id){
    //     $user = User::find($id);

    //     if(!$user)
    //     {
    //        return response()->json(['status' => false, 'message' => 'User not found']); 
    //     }
    //     $request->validate([
    //         'name' => 'required',
    //         'email' => 'required|email|unique:users,email,' . $id,
    //         'role' => 'required'
    //     ]);

    //     $user->update([
    //         'name' => $request->name,
    //         'email' => $request->email,
    //         'role' => $request->role,
    //     ]);
    //     return response()->json(['status' => true, 'message' => 'User Updated Successfully']);
    // }

    public function update(Request $request, $id)
    {
        $user = User::find($id);

        if (!$user) {
            return response()->json(['status' => false, 'message' => 'User not found']);
        }

        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users,email,' . $id,
            'role' => 'required|string',
            'team_id' => 'nullable|exists:teams,id',
        ]);

        $user->update([
            'name'  => $request->name,
            'email' => $request->email,
            'role'  => $request->role,
        ]);

        // Handle team assignment
        if ($request->role === 'Member' && $request->filled('team_id')) {
            // Remove existing and insert new
            DB::table('team_members')->updateOrInsert(
                ['user_id' => $user->id],
                ['team_id' => $request->team_id, 'updated_at' => now(), 'created_at' => now()]
            );
        } else {
            // If not member anymore, remove from team_members
            DB::table('team_members')->where('user_id', $user->id)->delete();
        }

        return response()->json(['status' => true, 'message' => 'User Updated Successfully']);
    }


    public function statusToggle($id)
    {
        $user = User::find($id);
        if ($user)
        {
            $user->status = !$user->status;
            $user->save();
            return response()->json(['status' => true, 'message' => 'Status Updated Successfully']);
        }
        return response()->json(['status' => false, 'message' => 'User Not Found']);
    }

    public function delete($id){
        $user = User::find($id);
        if ($user)
        {
            $user->delete();
            return response()->json(['status' => true, 'message' => 'User Deleted Successfully']);
        }
        return response()->json(['status' => false, 'message' => 'User Not Found']);
    }

    public function exportUsers()
    {
        $users = User::select('name', 'email', 'role', 'status')->get();
        $csvHeader = ['Name', 'Email', 'Role', 'Status'];
        $filename = 'users_export_' . now()->format('Y-m-d_H-i-s') . '.csv';

        $callback = function () use ($users, $csvHeader) {
            $file = fopen('php://output', 'w');
            fputcsv($file, $csvHeader);

            foreach ($users as $user) {
                fputcsv($file, [
                    ucwords($user->name),
                    $user->email,
                    ucfirst($user->role),
                    ucfirst($user->status),
                ]);
            }

            fclose($file);
        };

        return Response::stream($callback, 200, [
            "Content-Type" => "text/csv",
            "Content-Disposition" => "attachment; filename=$filename",
        ]);
    }
}
