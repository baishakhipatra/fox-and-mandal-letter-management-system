<?php $__env->startSection('content'); ?>


<div class="container mt-2">
        <div class="row">
            <div class="col-md-12">

                <?php if(session('status')): ?>
                    <div class="alert alert-success"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <div class="card data-card mt-3">
                    <div class="card-header">
                        <h4>Edit Logs
                             <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('csv export edit logs')): ?>
                            <a href="<?php echo e(route('edit-logs.export.csv',['date_from'=>$request->date_from,'date_to'=>$request->date_to])); ?>" class="btn btn-sm btn-cta ms-auto" data-bs-toggle="tooltip" title="Export data in CSV">
                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-download"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                                CSV
                            </a>
                            <?php endif; ?>
                        </h4>
                        <div class="search__filter mb-0">
                                    <div class="row">
                                        
                                    </div>
                                    <div class="row">
                                        
                                        <div class="col-12">
                                            <form action="">
                                                <div class="row">
                                                    <div class="col">
                                                        <input type="date" name="date_from" id="term" class="form-control form-control-sm"  value="<?php echo e(app('request')->input('date_from')); ?>">
                                                    </div>
                                                     <div class="col">
                                                        <input type="date" name="date_to" id="term" class="form-control form-control-sm"  value="<?php echo e(app('request')->input('date_to')); ?>">
                                                    </div>
                                                    
                                                </div>
                                                <div class="row mt-2">
                                                    <div class="col-12 text-end">
                                                        <!--<div class="btn-group books_btn_group">-->
                                                            <button type="submit" class="btn btn-sm btn-cta">
                                                                Filter
                                                            </button>
                            
                                                            <a href="<?php echo e(url()->current()); ?>" class="btn btn-sm btn-cta" data-bs-toggle="tooltip" title="Clear Filter">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                                                            </a>
                                                        <!--</div>-->
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        
                                    </div>
                                </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                            <thead>
                                <tr>
                                    <th class="index-col">#</th>
                                     <th>Module</th>
                                    <th>Record Details</th>
                                    
                                    <th>Field</th>
                                    <th>Previous Value</th>
                                    <!--<th>Property Name</th>-->
                                    <th>Updated Value</th>
                                    <th>Updated Date</th>
                                    <th>Updated By</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                  <?php
                                    if ($item->table_name && $item->record_id) {
                                        $modelClass = 'App\\Models\\' . ucfirst(Str::camel(Str::singular($item->table_name)));
                                
                                        if (class_exists($modelClass)) {
                                            $record = $modelClass::find($item->record_id);
                                            $item->record_details = $record;
                                           
                                        } else {
                                            $item->record_details = null;
                                        }
                                    }
                                    
                                    if ($item->updated_by && $item->updated_by) {
                                        $modelClass = 'App\\Models\User';
                                
                                        if (class_exists($modelClass)) {
                                            $record = $modelClass::find($item->updated_by);
                                            $item->user_details = $record;
                                           
                                        } else {
                                            $item->user_details = null;
                                        }
                                    }
                                  ?>
                                <tr>
                                    <td class="index-col"><?php echo e($index+1); ?></td>
                                     
                                    
                                    <td><?php echo e(ucwords(str_replace('_', ' ',$item->table_name)) ??''); ?> History</td> 
                                    <td><?php if($item->record_details): ?>
                                           <?php echo e($item->record_details->order_no ?? $item->record_details->order_no ?? 'Details available'); ?>

                                        <?php else: ?>
                                            Record not found
                                        <?php endif; ?>
                                    </td>
                                     <td><?php echo e($item->field ??''); ?></td>
                                     <td><?php echo e($item->old_value ??''); ?></td>
                                     <td><?php echo e($item->new_value ??''); ?></td>
                                     <td><?php echo e(date('d-m-Y', strtotime($item->created_at))); ?></td>
                                     <td><?php echo e($item->user_details->name ??''); ?></td>
                                               
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="9" class="text-center">No record found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        </div>
                         <?php echo e($data->appends($_GET)->render()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/vangu1yt/public_html/dev/fnm_lms/resources/views/facility/hotel-booking/logs.blade.php ENDPATH**/ ?>