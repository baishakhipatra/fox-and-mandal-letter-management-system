<?php $__env->startSection('content'); ?>


<div class="container mt-2">
        <div class="row">
            <div class="col-md-12">

                <?php if(session('status')): ?>
                    <div class="alert alert-success"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <div class="card data-card mt-3">
                    <div class="card-header">
                        <h4 class="d-flex">Train/Bus Booking Request
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('train booking list csv export')): ?>
                            <a href="<?php echo e(route('train-booking.export.csv',['date_from'=>$request->date_from,'date_to'=>$request->date_to,'bill_to'=>$request->bill_to,'keyword'=>$request->keyword])); ?>" class="btn btn-sm btn-cta ms-auto" data-bs-toggle="tooltip" title="Export data in CSV">
                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-download"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                                CSV
                            </a>
                            <?php endif; ?>
                        </h4>
                        <div class="search__filter mb-0">
                                    <div class="row">
                                        <div class="col-12">
                                            <p class="text-muted mt-1 mb-0">Showing <?php echo e($data->count()); ?> out of <?php echo e($data->total()); ?> Entries</p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        
                                        <div class="col-12">
                                            <form action="">
                                                <div class="row">
                                                    <div class="col">
                                                        <input type="date" name="date_from" id="term" class="form-control form-control-sm"  value="<?php echo e(app('request')->input('date_from')); ?>">
                                                    </div>
                                                     <div class="col">
                                                        <input type="date" name="date_to" id="term" class="form-control form-control-sm"  value="<?php echo e(app('request')->input('date_to')); ?>">
                                                    </div>
                                                    <div class="col">
                                                       <select class="form-select form-select-sm" aria-label="Default select example" name="bill_to" id="bill_to">
                                                            <option value="" selected disabled>Select Bill to</option>
                                                            <option value="1" <?php echo e(request('bill_to') == '1' ? 'selected' : ''); ?>>Company</option>
                                                            <option value="2" <?php echo e(request('bill_to') == '2' ? 'selected' : ''); ?>>Client</option>
                                                             <option value="3" <?php echo e(request('bill_to') == '3' ? 'selected' : ''); ?>>Matter Expenses</option>
                                                        </select>
                                                    </div>
                                                    
                                                    <div class="col">
                                                        <input type="search" name="keyword" id="term" class="form-control form-control-sm" placeholder="Search by keyword." value="<?php echo e(app('request')->input('keyword')); ?>" autocomplete="off">
                                                    </div>
                                                </div>
                                                <div class="row mt-2">
                                                    <div class="col-12 text-end">
                                                        <!--<div class="btn-group books_btn_group">-->
                                                            <button type="submit" class="btn btn-sm btn-cta">
                                                                Filter
                                                            </button>
                            
                                                            <a href="<?php echo e(url()->current()); ?>" class="btn btn-sm btn-cta" data-bs-toggle="tooltip" title="Clear Filter">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                                                            </a>
                                                        <!--</div>-->
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        
                                    </div>
                                </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                            <thead>
                                <tr>
                                    <th class="index-col">#</th>
                                    <th>Unique Code</th>
                                    <th>Member</th>
                                    <th>Type</th>
                                    <th>From</th>
                                    <th>To</th>
                                    <th>Trip Type</th>
                                    <th style="white-space:nowrap;">Travel Date & Time</th>
                                    <th>Return Date</th>
                                    <th>Traveller</th>
                                    <th>Seat Preference</th>
                                    <th>Food Preference</th>
                                    <th>Bill to</th>
                                    <th>Matter Code</th>
                                     <th>Purpose/description</th>
                                     <th>Booking Status</th>
                                    <th>Cancellation Reason</th>
                                     <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                
                                    <?php
                                        $travellers = explode(',', $item->traveller);
                                        $seatPreferences = explode(',', $item->seat_preference ?? '');
                                        $foodPreferences = explode(',', $item->food_preference ?? '');
                            
                                        $formattedTravellers = [];
                                        foreach ($travellers as $i => $traveller) {
                                            if (trim($traveller) !== '') {
                                                $formattedTravellers[] = [
                                                    'name' => trim($traveller),
                                                    'seat_preference' => $seatPreferences[$i] ?? 'N/A',
                                                    'food_preference' => $foodPreferences[$i] ?? 'N/A',
                                                ];
                                            }
                                        }
                                       // dd($formattedTravellers);
                                        
                                    $statusText = '';
                                    $statusClass = '';
                                
                                    switch ($item->status) {
                                        case 1:
                                            $statusText = 'Pending';
                                            $statusClass = 'text-warning';
                                            break;
                                        case 2:
                                            $statusText = 'Confirmed';
                                            $statusClass = 'text-primary';
                                            break;
                                        case 3:
                                            $statusText = 'Booked';
                                            $statusClass = 'text-success';
                                            break;
                                        default:
                                            $statusText = 'Cancelled';
                                            $statusClass = 'text-danger';
                                            break;
                                    }
                                
                                    ?>
                                    <?php if(count($formattedTravellers) > 0): ?>
                                        <?php $__currentLoopData = $formattedTravellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $traveller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                            <tr>
                                                <?php if($key == 0): ?>
                                                    <td class="index-col" rowspan="<?php echo e(count($formattedTravellers)); ?>"><?php echo e($index+1); ?></td>
                                                    <td rowspan="<?php echo e(count($formattedTravellers)); ?>"><?php echo e($item->order_no); ?></td>
                                                    <td rowspan="<?php echo e(count($formattedTravellers)); ?>">
                                                        <a href="<?php echo e(url('members/'.$item->user->id)); ?>"><?php echo e($item->user->name); ?></a>
                                                    </td>
                                                     <td rowspan="<?php echo e(count($formattedTravellers)); ?>"><?php echo e($item->type == 1 ? 'Train' :  'Bus'); ?></td>
                                                    <td rowspan="<?php echo e(count($formattedTravellers)); ?>"><?php echo e($item->from); ?></td>
                                                    <td rowspan="<?php echo e(count($formattedTravellers)); ?>"><?php echo e($item->to); ?></td>
                                                    <td rowspan="<?php echo e(count($formattedTravellers)); ?>">
                                                        <?php echo e($item->trip_type == 1 ? 'One way' : ($item->trip_type == 2 ? 'Round Trip' : '')); ?>

                                                    </td>
                                                    <td rowspan="<?php echo e(count($formattedTravellers)); ?>"><?php echo e($item->travel_date); ?></td>
                                                    
                                                    <td rowspan="<?php echo e(count($formattedTravellers)); ?>">
                                                        <?php echo e($item->trip_type == 2 ? ($item->return_date ?? '') : ''); ?>

                                                    </td>
                                                <?php endif; ?>
                                                <td><?php echo e($traveller['name'] ?? 'N/A'); ?></td>
                                                <td><?php echo e($traveller['seat_preference'] ?? 'N/A'); ?></td>
                                                <td><?php echo e($traveller['food_preference'] ?? 'N/A'); ?></td> <!-- New Column -->
                                                <?php if($key == 0): ?>
                                                    <td rowspan="<?php echo e(count($formattedTravellers)); ?>">
                                                        <?php echo e($item->bill_to == 1 ? 'Firm' : ($item->bill_to == 2 ? 'Third Party' : 'Matter Expenses')); ?>

                                                    </td>
                                                    <td rowspan="<?php echo e(count($formattedTravellers)); ?>"><?php echo e($item->matter_code); ?></td>
                                                    <td rowspan="<?php echo e(count($formattedTravellers)); ?>"><?php echo e($item->purpose_description ?? ''); ?></td>
                                                    <td><span class="<?php echo e($statusClass); ?>"><?php echo e($statusText); ?></span></td>
                                                     <?php if($item->status==4): ?>
                                                     <td><?php echo e($item->cancellation_remarks ??''); ?></td>
                                                     <?php else: ?>
                                                     <td></td>
                                                     <?php endif; ?>
                                                <?php endif; ?>
                                                
                                                 <?php if($key == 0): ?>
                                                <td style="white-space: nowrap;">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('train booking details')): ?>
                                                        <a href="<?php echo e(url('train-booking/details/'.$item->id)); ?>" class="btn btn-cta">
                                                            <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="512" height="512" x="0" y="0" viewBox="0 0 511.999 511.999" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M508.745 246.041c-4.574-6.257-113.557-153.206-252.748-153.206S7.818 239.784 3.249 246.035a16.896 16.896 0 0 0 0 19.923c4.569 6.257 113.557 153.206 252.748 153.206s248.174-146.95 252.748-153.201a16.875 16.875 0 0 0 0-19.922zM255.997 385.406c-102.529 0-191.33-97.533-217.617-129.418 26.253-31.913 114.868-129.395 217.617-129.395 102.524 0 191.319 97.516 217.617 129.418-26.253 31.912-114.868 129.395-217.617 129.395z" fill="#ffffff" opacity="1" data-original="#000000" class=""></path><path d="M255.997 154.725c-55.842 0-101.275 45.433-101.275 101.275s45.433 101.275 101.275 101.275S357.272 311.842 357.272 256s-45.433-101.275-101.275-101.275zm0 168.791c-37.23 0-67.516-30.287-67.516-67.516s30.287-67.516 67.516-67.516 67.516 30.287 67.516 67.516-30.286 67.516-67.516 67.516z" fill="#ffffff" opacity="1" data-original="#000000" class=""></path></g></svg>
                                                        </a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update train/bus booking')): ?>
                                                        <a href="<?php echo e(url('train-booking/'.$item->id.'/edit')); ?>" class="btn btn-cta">
                                                            <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="512" height="512" x="0" y="0" viewBox="0 0 492.493 492" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M304.14 82.473 33.165 353.469a10.799 10.799 0 0 0-2.816 4.949L.313 478.973a10.716 10.716 0 0 0 2.816 10.136 10.675 10.675 0 0 0 7.527 3.114 10.6 10.6 0 0 0 2.582-.32l120.555-30.04a10.655 10.655 0 0 0 4.95-2.812l271-270.977zM476.875 45.523 446.711 15.36c-20.16-20.16-55.297-20.14-75.434 0l-36.949 36.95 105.598 105.597 36.949-36.949c10.07-10.066 15.617-23.465 15.617-37.715s-5.547-27.648-15.617-37.719zm0 0" fill="#ffffff" opacity="1" data-original="#000000" class=""></path></g></svg>
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td class="index-col"><?php echo e($index+1); ?></td>
                                        <td><?php echo e($item->order_no); ?></td>
                                        <td style="white-space:nowrap;"><a href="<?php echo e(url('members/'.$item->user->id)); ?>"><?php echo e($item->user->name); ?></a></td>
                                        <td><?php echo e($item->type == 1 ? 'Train' :  'Bus'); ?></td>
                                        <td><?php echo e($item->from); ?></td>
                                        <td><?php echo e($item->to); ?></td>
                                        <td><?php echo e($item->trip_type == 1 ? 'One way' : ($item->trip_type == 2 ? 'Round Trip': '')); ?></td>
                                       
                                        <td><?php echo e($item->travel_date); ?></td>
                                         <?php if($item->trip_type == 2): ?>
                                        <td><?php echo e($item->return_date); ?></td>
                                        <?php else: ?>
                                        <td></td>
                                        <?php endif; ?>
                                        <td>N/A</td> <!-- No traveler -->
                                        <td>N/A</td> <!-- No seat preference -->
                                        <td>N/A</td>
                                        <td><?php echo e($item->bill_to == 1 ? 'Firm' : ($item->bill_to == 2 ? 'Third Party' : 'Matter Expenses')); ?></td>
                                        <td><?php echo e($item->matter_code); ?></td>
                                        <td><?php echo e($item->purpose_description ??''); ?></td>
                                        <td><span class="<?php echo e($statusClass); ?>"><?php echo e($statusText); ?></span></td>
                                             <?php if($item->status==4): ?>
                                             <td><?php echo e($item->cancellation_remarks ??''); ?></td>
                                             <?php else: ?>
                                             <td></td>
                                             <?php endif; ?>
                                    </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="9" class="text-center">No record found</td>
                                        </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        </div>
                         <?php echo e($data->appends($_GET)->render()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/vangu1yt/public_html/dev/fnm_lms/resources/views/facility/train-booking/index.blade.php ENDPATH**/ ?>