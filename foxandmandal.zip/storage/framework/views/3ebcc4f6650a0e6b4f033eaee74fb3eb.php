<?php $__env->startSection('content'); ?>


<div class="container mt-5">
        <div class="row">
            <div class="col-md-12">

                <?php if($errors->any()): ?>
                <ul class="alert alert-warning">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>

                <div class="card data-card">
                    <div class="card-header">
                        <h4 class="d-flex">Edit Cab Booking Detail
                            <a href="<?php echo e(url('cab-booking/list')); ?>" class="btn btn-cta ms-auto">Back</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-xl-3 col-lg-2 col-12"></div>
                            <div class="col-xl-6 col-lg-8 col-12">
                                <form action="<?php echo e(url('cab-booking/'.$data->id.'/update')); ?>" method="POST" class="data-form">
                                    <?php echo csrf_field(); ?>
                                   
        
                                    
                                    
                                    
                                    <div class="mb-3">
                                        <label for="">Location From</label>
                                        <input type="text" name="from_location" value="<?php echo e($data->from_location); ?>" class="form-control" />
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Location To</label>
                                        <input type="text" name="to_location" value="<?php echo e($data->to_location); ?>" class="form-control" />
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Pickup Date</label>
                                        <input type="date" name="pickup_date" value="<?php echo e(\Carbon\Carbon::parse($data->pickup_date)->format('Y-m-d')); ?>" class="form-control" />
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Pickup Time</label>
                                        <input type="time" name="pickup_time" value="<?php echo e($data->pickup_time); ?>" class="form-control" />
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Traveller</label>
                                        <input type="text" name="traveller[]" value="<?php echo e($data->traveller); ?>" class="form-control" multiple/>
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Bill To</label>
                                        <select name="bill_to" id="MbillSelect" class="form-control">
                                            <option value="1" <?php echo e($data->bill_to == 1 ? 'selected' : ''); ?>>Firm</option>
                                            <option value="2" <?php echo e($data->bill_to == 2 ? 'selected' : ''); ?>>Third Party</option>
                                            <option value="3" <?php echo e($data->bill_to == 3 ? 'selected' : ''); ?>>Matter Expenses</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3" id="MbillBox" style="display: none;">
                                        <label for="">Matter Code</label>
                                        <input type="text" id="matterCodeInput" name="matter_code" value="<?php echo e(old('matter_code', $data->matter_code ?? '')); ?>" class="form-control" />
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Purpose Description</label>
                                        <input type="text" name="purpose_description" value="<?php echo e($data->purpose_description); ?>" class="form-control" />
                                    </div>
                                    <div class="text-end mb-3">
                                        <button type="submit" class="btn btn-submit">Save</button>
                                    </div>
                                </form>
                            </div>
                            <div class="col-xl-3 col-lg-2 col-12"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script>
    $('select[name="office_id"]').on('change', (event) => {
        var value = $('select[name="office_id"]').val();
        OfficeChange(value);
    });
    <?php if(request()->input('office_id')): ?>
        OfficeChange(<?php echo e(request()->input('office_id')); ?>)
    <?php else: ?>
        OfficeChange(<?php echo e($data->office_id); ?>)
    <?php endif; ?>

    function OfficeChange(value) {
        $.ajax({
            url: '<?php echo e(url("/")); ?>/bookshelves/list/officewise/'+value,
            method: 'GET',
            success: function(result) {
                var content = '';
                var slectTag = 'select[name="bookshelves_id"]';
                var displayCollection =  "All";

                content += '<option value="" selected>'+displayCollection+'</option>';
                $.each(result.data, (key, value) => {
                    let selected = ``;
                    <?php if(request()->input('bookshelves_id')||$data->bookshelves_id): ?>
                        if(<?php echo e($data->bookshelves_id); ?> == value.id) {selected = 'selected';}
                    <?php endif; ?>
                    content += '<option value="'+value.id+'"'; content+=selected; content += '>'+value.number+'</option>';
                });
                $(slectTag).html(content).attr('disabled', false);
            }
        });
    }
    
    
    
     function toggleMatterCode() {
        var billTo = document.getElementById('MbillSelect').value;
        var billBox = document.getElementById('MbillBox');
        var matterCodeInput = document.getElementById('matterCodeInput');

        if (billTo === '3') {
            billBox.style.display = 'block';
        } else {
            billBox.style.display = 'none';
            matterCodeInput.value = ''; // Clear value only if needed
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        toggleMatterCode(); // Initial check
        document.getElementById('MbillSelect').addEventListener('change', toggleMatterCode);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/vangu1yt/public_html/dev/fnm_lms/resources/views/facility/cab-booking/edit.blade.php ENDPATH**/ ?>