<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="<?php echo e(asset('backend/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="https://cdn-uicons.flaticon.com/uicons-bold-rounded/css/uicons-bold-rounded.css" rel="stylesheet">
    <link href="<?php echo e(asset('backend/css/style.css')); ?>" rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo e(asset('backend/images/logo.png')); ?>" type="image/x-icon">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    
    <title>Fox & Mandal </title>
	
	<style>
		.page-item.active .page-link {
			background-color: rgb(219, 110, 76);
			border-color: rgb(219, 110, 76);
		}
		.page-link, .page-link:hover, .page-link:focus {
			color: rgb(219, 110, 76);
			box-shadow: none;
		}
	</style>
</head>

<body>
    <aside class="side__bar shadow-sm">
        <div class="admin__logo">
            <div class="logo">
                
                <img src="<?php echo e(asset('backend/images/logo.png')); ?>">
            </div>
            <div class="admin__info" style="width: 100% ; overflow : hidden" >
                <h1><?php echo e(Auth::user()->name); ?></h1>
                <p style="overflow : hidden;whitespace: narrow font-size:12px;font-size: 12px;" ><?php echo e(Auth::user()->email); ?></p>
            </div>
        </div>

        <nav class="main__nav">
            <ul>
                <li class="<?php echo e(( request()->is('home*') ) ? 'active' : ''); ?>"><a href="<?php echo e(route('home')); ?>"><i class="fi fi-br-home"></i> <span>Dashboard</span></a></li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view user')): ?>
                <li class="<?php echo e(( request()->is('users*') ) ? 'active' : ''); ?>"><a href="<?php echo e(route('users.index')); ?>"><i class="fi fi-br-user"></i> <span>Admin User Management</span></a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view role')): ?>
                <li class="<?php echo e(( request()->is('roles*') ) ? 'active' : ''); ?>"><a href="<?php echo e(route('roles.index')); ?>"><i class="fi fi-br-users-alt"></i> <span>Role Management</span></a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view permission')): ?>
                <li class="<?php echo e(( request()->is('permissions*') ) ? 'active' : ''); ?>"><a href="<?php echo e(route('permissions.index')); ?>"><i class="fi fi-br-chart-user"></i> <span>Permission Management</span></a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view member')): ?>
                        <li class="<?php echo e(( request()->is('members*') ) ? 'active' : ''); ?>"><a href="<?php echo e(route('members.index')); ?>"><i class="fi fi-br-user"></i> <span>Member Management</span></a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view office')): ?>
                        <li class="<?php echo e(( request()->is('offices*') ) ? 'active' : ''); ?>"><a href="<?php echo e(route('offices.index')); ?>"><i class="fi fi-br-database"></i> <span>Office Management</span></a></li>
                <?php endif; ?>
               
                
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('book list')): ?>
                <li class="<?php if(request()->is('bookcategories*')||request()->is('bookshelves*')||request()->is('books*')||request()->is('lostbooks*')||request()->is('unreturned/books*')||request()->is('issues*')||request()->is('bulk-issue/books/list*')): ?> { <?php echo e('active'); ?> }  <?php endif; ?>">
                    <a href="#"><i class="fi fi-br-cube"></i> <span>Lms Management</span></a>
                    <ul>
                        
                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('book category list')): ?>
                        <li class="<?php echo e(( request()->is('bookcategories*') ) ? 'active' : ''); ?>"><a href="<?php echo e(route('bookcategories.index')); ?>"><i class="fi fi-br-database"></i> <span>Book Category Management</span></a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bookshelve list')): ?>
                        <li class="<?php echo e(( request()->is('bookshelves*') ) ? 'active' : ''); ?>"><a href="<?php echo e(route('bookshelves.index')); ?>"><i class="fi fi-br-database"></i> <span>Bookshelves Management</span></a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('book list')): ?>
                        <li class="<?php echo e(( request()->is('books*') ) ? 'active' : ''); ?>"><a href="<?php echo e(route('books.index')); ?>"><i class="fi fi-br-book"></i> <span>Book Management</span></a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lost book list')): ?>
                        <li class="<?php echo e(( request()->is('lostbooks*') ) ? 'active' : ''); ?>"><a href="<?php echo e(route('lostbooks.index')); ?>"><i class="fi fi-br-book"></i> <span>Lost Book Management</span></a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Un-returned book list')): ?>
                        <li class="<?php echo e(( request()->is('unreturned/books*') ) ? 'active' : ''); ?>"><a href="<?php echo e(url('unreturned/books/list')); ?>"><i class="fi fi-br-book"></i> <span>Un-returned book list</span></a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view all book issue')): ?>
                        
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view all book bulkissue')): ?>
                        <li class="<?php echo e(( request()->is('bulk-issue/books/list*') ) ? 'active' : ''); ?>"><a href="<?php echo e(url('bulk-issue/books/list')); ?>"><i class="fi fi-br-book"></i> <span>Bulk issued book list</span></a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>
                
                 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view cab booking')): ?>
                <li class="<?php if(request()->is('cab-booking*')||request()->is('train-booking*')||request()->is('flight-booking*')||request()->is('hotel-booking*')||request()->is('properties*')|| request()->is('edit-logs/list*')): ?> { <?php echo e('active'); ?> }  <?php endif; ?>">
                    <a href="#"><i class="fi fi-br-cube"></i> <span>Travel Desk Management</span></a>
                    <ul>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view cab booking')): ?>
                        <li class="<?php echo e(( request()->is('cab-booking*') ) ? 'active' : ''); ?>"><a href="<?php echo e(url('cab-booking/list')); ?>"><i class="fi fi-br-database"></i> <span>Cab Booking Request</span></a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view train booking')): ?>
                        <li class="<?php echo e(( request()->is('train-booking*') ) ? 'active' : ''); ?>"><a href="<?php echo e(url('train-booking/list')); ?>"><i class="fi fi-br-database"></i> <span>Train/Bus Booking Request</span></a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view flight booking')): ?>
                        <li class="<?php echo e(( request()->is('flight-booking*') ) ? 'active' : ''); ?>"><a href="<?php echo e(url('flight-booking/list')); ?>"><i class="fi fi-br-database"></i> <span>Flight Booking Request</span></a></li>
                        <?php endif; ?>
                        <li class="<?php if(request()->is('properties*')||request()->is('hotel-booking*')): ?> { <?php echo e('active'); ?> }  <?php endif; ?>">
                            <a href="#"><i class="fi fi-br-cube"></i> <span>Property</span></a>
                            <ul>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('property list')): ?>
                                <li class="<?php echo e(( request()->is('properties*') ) ? 'active' : ''); ?>"><a href="<?php echo e(route('properties.index')); ?>"><i class="fi fi-br-database"></i> <span>Property Management</span></a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view hotel booking')): ?>
                                <li class="<?php echo e(( request()->is('hotel-booking*') ) ? 'active' : ''); ?>"><a href="<?php echo e(url('hotel-booking/list')); ?>"><i class="fi fi-br-database"></i> <span>Hotel Booking Request</span></a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                         <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view edit logs')): ?>
                        <li class="<?php echo e(( request()->is('edit-logs/list*') ) ? 'active' : ''); ?>"><a href="<?php echo e(url('edit-logs/list')); ?>"><i class="fi fi-br-database"></i> <span>Edit Logs</span></a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>
                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view cave form')): ?>
                <li class="<?php if(request()->is('vaults*')||request()->is('vaultlocations*')||request()->is('outside/vault/list')||request()->is('vaultcategories')): ?> { <?php echo e('active'); ?> }  <?php endif; ?>">
                    <a href="#"><i class="fi fi-br-cube"></i> <span>Cavity Management</span></a>
                    <ul>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view cave location')): ?>
                        <li class="<?php echo e(( request()->is('vaultlocations*') ) ? 'active' : ''); ?>"><a href="<?php echo e(route('vaultlocations.index')); ?>"><i class="fi fi-br-database"></i> <span>Cavity Location</span></a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view cavity room')): ?>
                         <li class="<?php echo e(( request()->is('vaultcategories*') ) ? 'active' : ''); ?>"><a href="<?php echo e(route('vaultcategories.index')); ?>"><i class="fi fi-br-database"></i> <span>Cavity Room</span></a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view cave form')): ?>
                        <li class="<?php echo e(( request()->is('vaults*') ) ? 'active' : ''); ?>"><a href="<?php echo e(route('vaults.index')); ?>"><i class="fi fi-br-database"></i> <span>Cavity List</span></a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view outside vault')): ?>
                        <li class="<?php echo e(( request()->is('outside/vault/list*') ) ? 'active' : ''); ?>"><a href="<?php echo e(route('outside.vault.list')); ?>"><i class="fi fi-br-database"></i> <span>Outside Cavity List</span></a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>
        </nav>
         <div class="nav__footer">
            <a href="javascript:void(0)" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i class="fi fi-br-cube"></i> <span>Log Out</span></a>
        </div>
    </aside>
    <main class="admin">
       <header>
            <div class="row align-items-center">
                <div class="col-auto ms-auto">
                    <div class="dropdown">
                        <button class="btn dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?>

                        </button>
                        <ul class="dropdown-menu test" aria-labelledby="dropdownMenuButton1">
                            <li><a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">Profile</a></li>
                            <li> <a class="dropdown-item" href="javascript:void(0)" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
								<i class="fi fi-br-sign-out"></i> 
								<span>Logout</span>
								</a>
							</li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>
        <section class="admin__title">
            <h1><?php echo $__env->yieldContent('page'); ?></h1>
        </section>

        <?php echo $__env->yieldContent('content'); ?>

        <footer>
            <div class="row">
                <div class="col-12 text-end">Fox & Mandal-<?php echo e(date('Y')); ?></div>
            </div>
        </footer>
    </main>

    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"><?php echo csrf_field(); ?></form>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="<?php echo e(asset('backend/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/30.0.0/classic/ckeditor.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('backend/js/custom.js')); ?>"></script>

   
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
		// tooltip
		var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
		var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
		  return new bootstrap.Tooltip(tooltipTriggerEl)
		})

        // click to select all checkbox
        function headerCheckFunc() {
            if ($('#flexCheckDefault').is(':checked')) {
                $('.tap-to-delete').prop('checked', true);
                clickToRemove();
            } else {
                $('.tap-to-delete').prop('checked', false);
                clickToRemove();
            }
        }

        // sweetalert fires | type = success, error, warning, info, question
        function toastFire(type = 'success', title, body = '') {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                showCloseButton: true,
                timer: 2000,
                timerProgressBar: false,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })

            Toast.fire({
                icon: type,
                title: title,
                // text: body
            })
        }

        // on session toast fires
        <?php if(Session::get('success')): ?>
            toastFire('success', '<?php echo e(Session::get('success')); ?>');
        <?php elseif(Session::get('failure')): ?>
            toastFire('warning', '<?php echo e(Session::get('failure')); ?>');
        <?php endif; ?>
    </script>
    
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH /home4/vangu1yt/public_html/dev/fnm_lms/resources/views/layouts/app.blade.php ENDPATH**/ ?>