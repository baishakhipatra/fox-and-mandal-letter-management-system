<?php $__env->startSection('content'); ?>


<div class="container mt-5">
        <div class="row">
            <div class="col-md-12">

                <?php if($errors->any()): ?>
                <ul class="alert alert-warning">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>

                <div class="card data-card">
                    <div class="card-header">
                        <h4 class="d-flex">Edit Train/Bus Booking Detail
                            <a href="<?php echo e(url('train-booking/list')); ?>" class="btn btn-cta ms-auto">Back</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-xl-3 col-lg-2 col-12"></div>
                            <div class="col-xl-6 col-lg-8 col-12">
                                <form action="<?php echo e(url('train-booking/'.$data->id.'/update')); ?>" method="POST" class="data-form">
                                    <?php echo csrf_field(); ?>
                                   
        
                                    
                                    <div class="mb-3">
                                        <label for="">Type</label>
                                        <select name="trip_type" id="tripTypeSelect" class="form-control">
                                            <option value="1" <?php echo e($data->type == 1 ? 'selected' : ''); ?>>Train</option>
                                            <option value="2" <?php echo e($data->type == 2 ? 'selected' : ''); ?>>Bus</option>
                                           
                                        </select>

                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="">Location From</label>
                                        <input type="text" name="from" value="<?php echo e($data->from); ?>" class="form-control" />
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Location To</label>
                                        <input type="text" name="to" value="<?php echo e($data->to); ?>" class="form-control" />
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Trip Type</label>
                                        <select name="trip_type" id="tripTypeSelectTrain" class="form-control">
                                            <option value="1" <?php echo e($data->trip_type == 1 ? 'selected' : ''); ?>>One Way</option>
                                            <option value="2" <?php echo e($data->trip_type == 2 ? 'selected' : ''); ?>>Round Trip</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="">Departure Date</label>
                                        <input type="datetime-local" name="travel_date"
                                            value="<?php echo e(\Carbon\Carbon::parse($data->travel_date)->format('Y-m-d\TH:i')); ?>"
                                            class="form-control" />
                                    </div>
                                    
                                    <div class="mb-3" id="trainreturnDateWrapper" style="<?php echo e($data->trip_type == 1 ? 'display:none;' : ''); ?>">
                                        <label for="">Return Date</label>
                                        <input type="date" name="return_date" id="trainreturnDateInput"
                                            value="<?php echo e($data->return_date ? \Carbon\Carbon::parse($data->return_date)->format('Y-m-d') : ''); ?>"
                                            class="form-control" />
                                    </div>
                                    <?php
                                        $prefixes = ['Mr.', 'Mrs.', 'Ms.', 'Dr.'];
                                        $travellers = explode(',', $data->traveller ?? '');
                                        $seatPreferences = explode(',', $data->seat_preference ?? '');
                                        $foodPreferences = explode(',', $data->food_preference ?? '');
                                    ?>
                                    
                                    <div id="traveller-container">
                                        <?php $__currentLoopData = $travellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $fullTraveller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $fullTraveller = trim($fullTraveller);
                                                $selectedPrefix = '';
                                                $nameOnly = $fullTraveller;
                                    
                                                foreach ($prefixes as $prefix) {
                                                    if (str_starts_with($fullTraveller, $prefix)) {
                                                        $selectedPrefix = $prefix;
                                                        $nameOnly = trim(str_replace($prefix, '', $fullTraveller));
                                                        break;
                                                    }
                                                }
                                            ?>
                                    
                                            <div class="row mb-2 traveller-group">
                                                <div class="col-md-3">
                                                    <label>Prefix</label>
                                                    <select name="prefix[]" class="form-control">
                                                        <?php $__currentLoopData = $prefixes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prefix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($prefix); ?>" <?php echo e($selectedPrefix == $prefix ? 'selected' : ''); ?>><?php echo e($prefix); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="col-md-3">
                                                    <label>Traveller</label>
                                                    <input type="text" name="traveller[]" class="form-control" value="<?php echo e($nameOnly); ?>">
                                                </div>
                                                <div class="col-md-3">
                                                    <label>Seat Preference</label>
                                                    <!--<input type="text" name="seat_preference[]" class="form-control" value="<?php echo e($seatPreferences[$index] ?? ''); ?>">-->
                                                    <select name="seat_preference[]" id="seat_preference" class="form-control">
                                                        <option value="AC1" <?php echo e($seatPreferences[$index] == 'AC1' ? 'selected' : ''); ?>>AC1</option>
                                                        <option value="AC2" <?php echo e($seatPreferences[$index] == 'AC2' ? 'selected' : ''); ?>>AC2</option>
                                                        <option value="AC3" <?php echo e($seatPreferences[$index] == 'AC3' ? 'selected' : ''); ?>>AC3</option>
                                                        <option value="ACC" <?php echo e($seatPreferences[$index] == 'ACC' ? 'selected' : ''); ?>>ACC</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-3">
                                                    <label>Food Preference</label>
                                                    <!--<input type="text" name="food_preference[]" class="form-control" value="<?php echo e($foodPreferences[$index] ?? ''); ?>">-->
                                                    <select name="food_preference[]" id="food_preference" class="form-control">
                                                        <option value="Veg" <?php echo e($foodPreferences[$index] == 'Veg' ? 'selected' : ''); ?>>Veg</option>
                                                        <option value="Non-Veg" <?php echo e($foodPreferences[$index] == 'Non-Veg' ? 'selected' : ''); ?>>Non-Veg</option>
                                                    </select>
                                                </div>
                                                <div class="col-12 mt-1">
                                                    <button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.traveller-group').remove()">Remove</button>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    
                                    <button type="button" class="btn btn-success btn-sm mb-3" onclick="addTravellerRow()">+ Add More</button>
                                    <div class="mb-3">
                                        <label for="">Bill To</label>
                                        <select name="bill_to" id="MbillSelect" class="form-control">
                                            <option value="1" <?php echo e($data->bill_to == 1 ? 'selected' : ''); ?>>Firm</option>
                                            <option value="2" <?php echo e($data->bill_to == 2 ? 'selected' : ''); ?>>Third Party</option>
                                            <option value="3" <?php echo e($data->bill_to == 3 ? 'selected' : ''); ?>>Matter Expenses</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3" id="MbillBox" style="display: none;">
                                        <label for="">Matter Code</label>
                                        <input type="text" id="matterCodeInput" name="matter_code" value="<?php echo e(old('matter_code', $data->matter_code ?? '')); ?>" class="form-control" />
                                    </div>
                                    <div class="mb-3">
                                        <label for="">Purpose Description</label>
                                        <input type="text" name="purpose_description" value="<?php echo e($data->purpose_description); ?>" class="form-control" />
                                    </div>
                                    <?php if($data->status==3): ?>
                                    <div class="mb-3">
                                        <label for="">PNR</label>
                                        <input type="text" name="pnr" value="<?php echo e($data->pnr); ?>" class="form-control" />
                                    </div>
                                    <?php endif; ?>
                                    <div class="text-end mb-3">
                                        <button type="submit" class="btn btn-submit">Save</button>
                                    </div>
                                </form>
                            </div>
                            <div class="col-xl-3 col-lg-2 col-12"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script>
  const traintripType = document.getElementById("tripTypeSelectTrain");
    const trainreturnDateWrapper = document.getElementById("trainreturnDateWrapper");
    const trainreturnDateInput = document.getElementById("trainreturnDateInput");

    function toggletrainReturnDate() {
        if (traintripType.value === "2") {
            trainreturnDateWrapper.style.display = "block";
        } else {
            trainreturnDateWrapper.style.display = "none";
            trainreturnDateInput.value = ""; // clear the return date if One Way selected
        }
    }

    traintripType.addEventListener("change", toggletrainReturnDate);
    toggletrainReturnDate(); // run on page load
    
    

     function toggleMatterCode() {
        var billTo = document.getElementById('MbillSelect').value;
        var billBox = document.getElementById('MbillBox');
        var matterCodeInput = document.getElementById('matterCodeInput');

        if (billTo === '3') {
            billBox.style.display = 'block';
        } else {
            billBox.style.display = 'none';
            matterCodeInput.value = ''; // Clear value only if needed
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        toggleMatterCode(); // Initial check
        document.getElementById('MbillSelect').addEventListener('change', toggleMatterCode);
    });
    
    
    
    
    function addTravellerRow() {
    let container = document.getElementById('traveller-container');
    let row = document.createElement('div');
    row.classList.add('row', 'mb-2', 'traveller-group');

    row.innerHTML = `
        <div class="col-md-3">
            <label>Prefix</label>
            <select name="prefix[]" class="form-control">
                <option value="Mr.">Mr.</option>
                <option value="Mrs.">Mrs.</option>
                <option value="Ms.">Ms.</option>
                <option value="Dr.">Dr.</option>
            </select>
        </div>
        <div class="col-md-3">
            <label>Traveller</label>
            <input type="text" name="traveller[]" class="form-control">
        </div>
        <div class="col-md-3">
            <label>Seat Preference</label>
           
            <select name="seat_preference[]" id="seat_preference" class="form-control">
                <option value="AC1" <?php echo e($seatPreferences[$index] == 'AC1' ? 'selected' : ''); ?>>AC1</option>
                <option value="AC2" <?php echo e($seatPreferences[$index] == 'AC2' ? 'selected' : ''); ?>>AC2</option>
                <option value="AC3" <?php echo e($seatPreferences[$index] == 'AC3' ? 'selected' : ''); ?>>AC3</option>
                 <option value="ACC" <?php echo e($seatPreferences[$index] == 'ACC' ? 'selected' : ''); ?>>ACC</option>
            </select>
        </div>
        <div class="col-md-3">
            <label>Food Preference</label>
           <select name="food_preference[]" id="food_preference" class="form-control">
                <option value="Veg" <?php echo e($foodPreferences[$index] == 'Veg' ? 'selected' : ''); ?>>Veg</option>
                <option value="Non-Veg" <?php echo e($foodPreferences[$index] == 'Non-Veg' ? 'selected' : ''); ?>>Non-Veg</option>
            </select>
        </div>
        <div class="col-12 mt-1">
            <button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.traveller-group').remove()">Remove</button>
        </div>
    `;
    container.appendChild(row);
    }
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/vangu1yt/public_html/dev/fnm_lms/resources/views/facility/train-booking/edit.blade.php ENDPATH**/ ?>