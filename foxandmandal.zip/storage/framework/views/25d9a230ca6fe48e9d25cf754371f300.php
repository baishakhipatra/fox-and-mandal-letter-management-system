<?php $__env->startSection('content'); ?>

<div class="container mt-5">
        <div class="row">
            <div class="col-md-12">

                <?php if(session('status')): ?>
                    <div class="alert alert-success"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <div class="card data-card">
                    <div class="card-header">
                        <h4 class="d-flex align-items-center">
                            Role : <?php echo e(ucfirst( $role->name)); ?>

                            <p>&nbsp;&nbsp;&nbsp;(Add/Edit Permission)</p>
                            <a href="<?php echo e(url('roles')); ?>" class="btn btn-cta ms-auto">Back</a>
                        </h4>
                        
                    </div>
                    <div class="card-body" style="max-width: 100%; overflow: auto;">
                        <form action="<?php echo e(url('roles/'.$role->id.'/give-permissions')); ?>" method="POST" class="data-form">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                    
                            <div class="mb-3">
                                <?php $__errorArgs = ['permission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                                    <div class="row">
                                        <!-- Loop through each category -->
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <?php
                                             if($category=='admin'){
                                              $category='Admin Management';
                                              }elseif($category=='lms'){
                                                 $category='Library Management';
                                              }elseif($category=='fms'){
                                                $category='Facility Management';
                                              }elseif($category=='member'){
                                                $category='Member Management';
                                              }else{
                                                 $category='Cave Management';
                                              }
                                              
                                           ?>
                                            <div class="col-md-3">
                                                <h5 class="category-title"><?php echo e($category); ?></h5>
                                                <!-- Loop through each permission within the category -->
                                                <div class="permissions-list">
                                                    <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="form-check">
                                                            <input
                                                                type="checkbox"
                                                                name="permission[]"
                                                                class="form-check-input"
                                                                value="<?php echo e($item->name); ?>"
                                                                <?php echo e(in_array($item->id, $rolePermissions) ? 'checked':''); ?>

                                                            />
                                                            <label class="form-check-label">
                                                                <?php echo e(ucfirst( $item->name)); ?>

                                                            </label>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                    
                            </div>
                            <div class="text-end mb-3">
                                <button type="submit" class="btn btn-submit">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/vangu1yt/public_html/dev/fnm_lms/resources/views/role-permission/role/add-permissions.blade.php ENDPATH**/ ?>