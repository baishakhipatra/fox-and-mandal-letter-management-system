

<?php $__env->startSection('content'); ?>
<div class="container mt-2">
        <div class="col-md-12">
            <div class="row">
                <div class="container mt-2">
                    <div class="col-md-12">
                        <div class="row">

                            <div class="col-md-4 mb-4">
                                <div class="card shadow-sm rounded p-3 d-flex flex-row align-items-center justify-content-between">
                                    <div>
                                        <div class="text-muted">Total Letters</div>
                                        <div class="h5 mb-0 font-weight-bold text-dark"><?php echo e($total); ?></div>
                                    </div>
                                    <div class="bg-dark text-white rounded-circle p-2">
                                        <i class="fas fa-file-alt"></i>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4 mb-4">
                                <div class="card shadow-sm rounded p-3 d-flex flex-row align-items-center justify-content-between">
                                    <div>
                                        <div class="text-muted">Total Received</div>
                                        <div class="h5 mb-0 font-weight-bold text-dark"><?php echo e($delivered); ?></div>
                                    </div>
                                    <div class="bg-success text-white rounded-circle p-2">
                                        <i class="fas fa-check-circle"></i>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4 mb-4">
                                <div class="card shadow-sm rounded p-3 d-flex flex-row align-items-center justify-content-between">
                                    <div>
                                        <div class="text-muted">Pending to Receive</div>
                                        <div class="h5 mb-0 font-weight-bold text-dark"><?php echo e($pending); ?></div>
                                    </div>
                                    <div class="bg-warning text-white rounded-circle p-2">
                                        <i class="fas fa-file-contract"></i>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>  
                <div class="card mt-3">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Letter List</h5>
                        <a href="<?php echo e(route('home', ['status' => 'Delivered'])); ?>" class="btn btn-outline-dark btn-sm">
                            Show Only Delivered
                        </a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered mb-0">
                            <thead>
                                <tr>
                                    <th>Letter ID</th>
                                    <th>Subject</th>
                                    <th>Status</th>
                                    <th>Created At</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $letters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($letter->letter_id); ?></td>
                                        <td><?php echo e($letter->subject ?? 'N/A'); ?></td>
                                        <td>
                                            <span class="badge <?php echo e($letter->status == 'Delivered' ? 'bg-success' : 'bg-warning text-dark'); ?>">
                                                <?php echo e($letter->status); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e(\Carbon\Carbon::parse($letter->created_at)->format('d-m-Y')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="4" class="text-center">No letters found.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\fnm_lms\resources\views/admin/member/dashboard.blade.php ENDPATH**/ ?>