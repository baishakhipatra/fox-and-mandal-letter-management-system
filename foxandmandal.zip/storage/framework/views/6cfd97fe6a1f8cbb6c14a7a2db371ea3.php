<!DOCTYPE html>
<html>

<head>
    <title>Letter Report</title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .info {
            margin-bottom: 10px;
        }

        .label {
            font-weight: bold;
        }

        .signature img {
            max-width: 200px;
            margin-top: 15px;
        }
    </style>
</head>

<body>
    <h2>Letter Report</h2>

    <div class="info"><span class="label">Letter ID:</span> <?php echo e($letter->letter_id); ?></div>
    <div class="info"><span class="label">Status:</span> <?php echo e(ucfirst($letter->status)); ?></div>
    <div class="info"><span class="label">Received From:</span> <?php echo e(ucwords($letter->received_from)); ?></div>
    <div class="info"><span class="label">Document Name:</span> <?php echo e(ucwords($letter->subject) ?? 'N/A'); ?></div>
    <div class="info"><span class="label">Send To:</span>
        <?php if($letter->delivery && $letter->delivery->deliveredToUser): ?>
        <?php echo e($letter->delivery->deliveredToUser->name); ?>

        <?php if($letter->delivery->deliveredToUser->team->isNotEmpty()): ?>
        (<?php echo e($letter->delivery->deliveredToUser->team->pluck('name')->join(', ')); ?>)
        <?php endif; ?>
        <?php else: ?>
        <?php echo e($letter->send_to ?? 'Not specified'); ?>

        <?php endif; ?>
    </div>
    <div class="info"><span class="label">Handed Over By:</span> <?php echo e(ucwords($letter->handedOverByUser)->name ?? 'Unassigned'); ?></div>
    <div class="info"><span class="label">Reference No:</span> <?php echo e($letter->reference_no ?? 'N/A'); ?></div>
    <div class="info"><span class="label">Created:</span>
        <?php echo e(\Carbon\Carbon::parse($letter->created_at)->format('m/d/Y')); ?></div>
    <div class="info"><span class="label">Delivered Date:</span>
        <?php echo e($letter->delivery ? \Carbon\Carbon::parse($letter->delivery->delivered_at)->format('m/d/Y') : 'Not Delivered'); ?>

    </div>

    <?php
        $signaturePath = public_path($letter->delivery->signature_image_path);
       
    ?>

    <?php if($letter->delivery && file_exists($signaturePath)): ?>
        <div class="signature">
            <div class="label">Signature:</div>
            <img src="<?php echo e($signaturePath); ?>" style="width: 150px;" alt="Signature">
        </div>
    <?php endif; ?>

</body>

</html>
<?php /**PATH C:\xampp2\htdocs\fnm_lms\resources\views/admin/delivery-management/pdf.blade.php ENDPATH**/ ?>