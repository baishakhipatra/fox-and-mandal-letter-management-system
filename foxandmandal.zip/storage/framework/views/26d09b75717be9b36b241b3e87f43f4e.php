<?php $__env->startSection('content'); ?>


<div class="container mt-2">
        <div class="row">
            <div class="col-md-12">

                <?php if(session('status')): ?>
                    <div class="alert alert-success"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <div class="card mt-3">
                    <div class="card-header">
                        <h4>Available book Details of <?php echo e($office->name); ?> (<?php echo e($office->address); ?>)
                            
                        </h4>
                                <div class="search__filter mb-0">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <p class="text-muted mt-1 mb-0">Showing <?php echo e($data->count()); ?> out of <?php echo e($data->total()); ?> Entries</p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        
                                        <div class="col-md-12 text-end">
                                            <form class="row align-items-end" action="">
                                               
                                                <div class="col">
                                                    <select class="form-select form-select-sm" aria-label="Default select example" name="bookshelves_id" id="bookshelves">
                                                        <option value="" selected disabled>Select Bookshelve</option>
                                                        
                                                            <option value="">Select Office  first</option>
                                                        
                                                    </select>
                                                </div>
                                                <div class="col">
                                                    <select class="form-select form-select-sm" aria-label="Default select example" name="category_id" id="category_id">
                                                        <option value="" selected disabled>Select Category</option>
                                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($cat->id); ?>" <?php echo e(request()->input('category_id') == $cat->id ? 'selected' : ''); ?>> <?php echo e($cat->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="col">
                                                    <input type="search" name="keyword" id="term" class="form-control form-control-sm" placeholder="Search by keyword." value="<?php echo e(app('request')->input('keyword')); ?>" autocomplete="off">
                                                </div>
                                                <div class="col">
                                                    <div class="btn-group">
                                                        <button type="submit" class="btn btn-danger btn-sm">
                                                            Filter
                                                        </button>
                        
                                                        <a href="<?php echo e(url()->current()); ?>" class="btn btn-sm btn-light" data-bs-toggle="tooltip" title="Clear Filter">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                                                        </a>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('book csv export')): ?>
                                                        <a href="<?php echo e(url('books/export/csv'). '?office_id=' . $office->id.'&bookshelves_id='. $request->bookshelves_id.'&category_id'.$request->category_id.'&keyword'.$request->keyword); ?>" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Export data in CSV">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-download"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                                                            CSV
                                                        </a>
                                                        <?php endif; ?>
                                                        
                                                        
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th class="sl_no">#</th>
                                    <th>UID</th>
                                    <th>Office</th>
                                    <th class="bookshelf">Office Location</th>
                                    <th class="bookshelf">Bookshelf Number</th>
                                    <th>Category</th>
                                    <th>Title</th>
                                    <th>Author</th>
                                    <th>Status</th>
                                    <th>Qrcode</th>
                                    <th width="40%">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index+1); ?></td>
                                    <td><?php echo e($item->uid ??''); ?></td>
                                    <td><?php echo e($item->office->name ??''); ?></td>
                                    <td><?php echo e($item->office->address ??''); ?></td>
                                    <td><?php echo e($item->bookshelves->number); ?></td>
                                    <td><?php echo e($item->category->name); ?></td>
                                    <td><?php echo e($item->title); ?></td>
                                    
                                    <td><?php echo e($item->author ??''); ?></td>
                                    <td> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('book status change')): ?><a href="<?php echo e(url('books/'.$item->id.'/status/change')); ?>" ><span class="badge bg-<?php echo e(($item->status == 1) ? 'success' : 'danger'); ?>"><?php echo e(($item->status == 1) ? 'Active' : 'Inactive'); ?></span></a><?php endif; ?></td>
                                    <td><img src="https://bwipjs-api.metafloor.com/?bcid=qrcode&text=<?php echo e($item->qrcode); ?>&height=6&textsize=10&scale=6&includetext" alt="" style="height: 105px;width:105px" id="<?php echo e($item->qrcode); ?>"></td>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update book')): ?>
                                        <a href="<?php echo e(url('books/'.$item->id.'/edit')); ?>" class="btn btn-success ">Edit</a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view book')): ?>
                                        <a href="<?php echo e(url('books/'.$item->id)); ?>" class="btn btn-secondary mx-2">View</a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete book')): ?>
                                        <a onclick="return confirm('Are you sure ?')" href="<?php echo e(url('books/'.$item->id.'/delete')); ?>" class="btn btn-danger mx-2">Delete</a><br>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('book issue list')): ?>
                                        <a href="<?php echo e(url('books/'.$item->id.'/issue/list')); ?>" class="btn btn-primary mt-2">Number of Issues</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        </div>
                        <?php echo $data->render(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>



<div class="modal fade" id="csvModal" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                Bulk Upload
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="post" action="<?php echo e(url('books/upload/csv')); ?>" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                    <input type="file" name="file" class="form-control" accept=".csv">
                    <br>
                    <a href="<?php echo e(asset('backend/csv/sample-book.csv')); ?>">Download Sample CSV</a>
                    <br>
                    <button type="submit" class="btn btn-danger mt-3" id="csvImportBtn">Import <i class="fas fa-upload"></i></button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        var officeId = '<?php echo e($office->id); ?>';
        var bookshelvesId = '<?php echo e(request()->input('bookshelves_id')); ?>';

        // Check if office_id is present
        if (officeId) {
            OfficeChange(officeId);
        } else if (bookshelvesId) {
            // If office_id is not present but bookshelves_id is, fetch and show the specific bookshelf
            FetchBookshelfById(bookshelvesId);
        }

        
            var value = '<?php echo e($office->id); ?>';
            OfficeChange(value);
        
    });

    function OfficeChange(value) {
        $.ajax({
            url: `<?php echo e(url('/bookshelves/list/officewise')); ?>/${value}`,
            method: 'GET',
            success: function(result) {
                var slectTag = 'select[name="bookshelves_id"]';
                var displayCollection = "All";
                var bookshelvesId = '<?php echo e(request()->input('bookshelves_id')); ?>';

                var content = `<option value="">${displayCollection}</option>`;
                $.each(result.data, function(key, value) {
                    let selected = (bookshelvesId == value.id) ? 'selected' : '';
                    content += `<option value="${value.id}" ${selected}>${value.number}</option>`;
                });

                $(slectTag).html(content).attr('disabled', false);
            }
        });
    }

    function FetchBookshelfById(bookshelvesId) {
        $.ajax({
            url: `<?php echo e(url('/bookshelves/get')); ?>/${bookshelvesId}`,  // Assumes you have a route to fetch a single bookshelf by ID
            method: 'GET',
            success: function(result) {
                var slectTag = 'select[name="bookshelves_id"]';
                var content = '';

                if (result.data) {
                    content += `<option value="${result.data.id}" selected>${result.data.number}</option>`;
                } else {
                    content += `<option value="" selected>No bookshelf found</option>`;
                }

                $(slectTag).html(content).attr('disabled', false);
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/vangu1yt/public_html/dev/fnm_lms/resources/views/lms/book/book-office-detail.blade.php ENDPATH**/ ?>